package Login_Sys;

import java.awt.EventQueue;

import javax.swing.JFrame;
//import javax.swing.JEditorPane;
//import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Details {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	//public static void NewScreen() {
		public static void main(String[] args) {	
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Details window = new Details();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Details() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.GREEN);
		frame.setBounds(100, 100, 889, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		ImageIcon icon4=new ImageIcon(this.getClass().getResource("/star.png"));
		lblNewLabel.setIcon(icon4);
		lblNewLabel.setBounds(0, 0, 121, 131);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PLAY THE GAME");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 36));
		lblNewLabel_1.setBounds(131, 0, 744, 118);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBackground(Color.WHITE);
		ImageIcon icon=new ImageIcon(this.getClass().getResource("/le3.JPG"));
		lblNewLabel_2.setIcon(icon);	
		lblNewLabel_2.setBounds(0, 141, 576, 572);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("PLAY GAME");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//loading lo=new loading();
				//lo.NewScreen();
				
				
			}
		});
		btnNewButton.setBackground(Color.CYAN);
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		btnNewButton.setBounds(586, 172, 253, 80);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("VIEW SCORE");
		btnNewButton_1.setBackground(Color.CYAN);
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		btnNewButton_1.setBounds(586, 310, 259, 71);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("BACK");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
			}
		});
		btnNewButton_2.setBackground(Color.CYAN);
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		btnNewButton_2.setBounds(586, 449, 253, 71);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		ImageIcon icon5=new ImageIcon(this.getClass().getResource("/star.png"));
		lblNewLabel_3.setIcon(icon5);
		lblNewLabel_3.setBounds(718, 555, 121, 131);
		frame.getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton_3 = new JButton("RATE US");
		btnNewButton_3.setBackground(Color.CYAN);
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_3.setBounds(586, 572, 122, 101);
		frame.getContentPane().add(btnNewButton_3);
	}

}
