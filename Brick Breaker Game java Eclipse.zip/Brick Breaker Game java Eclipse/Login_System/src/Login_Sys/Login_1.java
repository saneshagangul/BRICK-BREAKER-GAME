package Login_Sys;

import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;


public class Login_1 {

	private JFrame frame;
	private JTextField txtUserName;
	private JTextField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_1 window = new Login_1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 889, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUserName = new JLabel("userName");
		lblUserName.setOpaque(true);
		lblUserName.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserName.setForeground(Color.WHITE);
		lblUserName.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblUserName.setBackground(Color.BLACK);
		lblUserName.setBounds(49, 224, 155, 34);
		frame.getContentPane().add(lblUserName);
		
		txtUserName = new JTextField();
		txtUserName.setColumns(10);
		txtUserName.setBounds(321, 218, 240, 40);
		frame.getContentPane().add(txtUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setOpaque(true);
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPassword.setBackground(Color.BLACK);
		lblPassword.setBounds(49, 298, 155, 34);
		frame.getContentPane().add(lblPassword);
		
		txtPassword = new JPasswordField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(321, 292, 240, 40);
		frame.getContentPane().add(txtPassword);
		
		JButton btnlogin = new JButton("LOGIN");
		btnlogin.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnlogin.setBackground(Color.CYAN);
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cis_game","root","");
				Statement stmt=con.createStatement();
				String sql="SELECT * FROM `game_login` WHERE User_Name='"+txtUserName.getText()+"' and Password='"+txtPassword.getText()+"' ";
				ResultSet rs=stmt.executeQuery(sql);
				if(rs.next())
				{
					JOptionPane.showMessageDialog(null, "Login Sucessfully...");
				}else {
					JOptionPane.showMessageDialog(null, "Incorrect username and Password...");
				}
				con.close();
					
				//String  password=txtPassword.getText();
				//String  username=txtUserName.getText();
				}catch(Exception ex) {
					System.out.print(ex);
				}
				
				
			/*	if(password.contains("King") && username.contains("one") )
						{
					       txtPassword.setText(null);
					       txtUserName.setText(null);
					       
					       //Travelling info=new Travelling();
					       //Details detail1=new Details();
					       //Travelling.main(null);
 					       //  detail1.NewScreen();
					       //info.main(null);
					       
						}else
						{
						   	JOptionPane.showMessageDialog(null,"Invalid Login Details","Login Error",JOptionPane.ERROR_MESSAGE);
						}
				
				*/
				
				
				
				
			}
		});
		
		btnlogin.setBounds(49, 648, 119, 40);
		frame.getContentPane().add(btnlogin);
		
		JButton btnSignIn = new JButton("SIGN IN");
		btnSignIn.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnSignIn.setBackground(Color.CYAN);
		btnSignIn.setBounds(193, 648, 119, 40);
		frame.getContentPane().add(btnSignIn);
		
		JButton btnRESET = new JButton("RESET");
		btnRESET.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtUserName.setText(null);
				txtPassword.setText(null); 
				
				
			}
		});
		btnRESET.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnRESET.setBackground(Color.CYAN);
		btnRESET.setBounds(419, 648, 119, 40);
		frame.getContentPane().add(btnRESET);
		
		JButton btnEXIT = new JButton("EXIT");
		btnEXIT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFrame frmLoginSystem = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frmLoginSystem,"Confirm if you want to exit","Login Systems",JOptionPane.YES_NO_OPTION
						)==JOptionPane.YES_NO_OPTION) {
					
					System.exit(0);
				}
				
			}
		});
		btnEXIT.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnEXIT.setBackground(Color.CYAN);
		btnEXIT.setBounds(657, 648, 119, 40);
		frame.getContentPane().add(btnEXIT);
		
		JLabel lblNewLabel = new JLabel("");
		ImageIcon icon=new ImageIcon(this.getClass().getResource("/edit11.jpg"));
		lblNewLabel.setIcon(icon);	
		lblNewLabel.setBounds(0, 0, 875, 713);
		frame.getContentPane().add(lblNewLabel);
	}
}
