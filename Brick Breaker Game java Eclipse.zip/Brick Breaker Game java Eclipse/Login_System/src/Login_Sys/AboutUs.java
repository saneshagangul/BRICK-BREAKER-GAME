package Login_Sys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;

public class AboutUs {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AboutUs window = new AboutUs();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AboutUs() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 889, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea txtrThisGameIs = new JTextArea();
		txtrThisGameIs.setFont(new Font("Times New Roman", Font.BOLD, 12));
		txtrThisGameIs.setForeground(new Color(255, 255, 255));
		txtrThisGameIs.setBackground(Color.BLACK);
		txtrThisGameIs.setText("This Game is develop by U.H.SANESHA GANGUL to the  final year CIS Subject Assignment.                                                                                                                                                \r\n                                         \r\n                                              Developer : U.H.SANESHA GANGUL\r\n                      Degree:Bsc.(Hons) Computer Science and Software Engineering\r\n                                   Subject:COMPARATIVE INTEGRATED SYSTEMS\r\n                                                           Index No:2115179   \r\n                                                            SLIIT ACADEMY");
		txtrThisGameIs.setBounds(138, 594, 504, 109);
		frame.getContentPane().add(txtrThisGameIs);
		
		JLabel lblNewLabel = new JLabel("");
		ImageIcon icon3=new ImageIcon(this.getClass().getResource("/ab.jpg"));
		lblNewLabel.setIcon(icon3);
		lblNewLabel.setBounds(0, 10, 875, 713);
		frame.getContentPane().add(lblNewLabel);
	}
}
