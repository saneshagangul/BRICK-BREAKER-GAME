package Login_Sys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Main_L {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_L window = new Main_L();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main_L() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 782, 613);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("CONTINUE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			//	Details details=new Details();
				//details.NewScreen();
				
			}
		});
		btnNewButton.setBackground(Color.CYAN);
		btnNewButton.setBounds(633, 350, 100, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("RATE US");
		btnNewButton_1.setBackground(Color.CYAN);
		btnNewButton_1.setBounds(633, 392, 100, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton(" ABOUT US");
		btnNewButton_2.setBackground(Color.CYAN);
		btnNewButton_2.setBounds(633, 436, 100, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("NEW GAME");
		btnNewButton_3.setBackground(Color.CYAN);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//double click the button after that there is available
				//Login_S login=new Login_S();
				//login.NewScreen();
				
			}
		});
		btnNewButton_3.setBounds(633, 309, 100, 21);
		frame.getContentPane().add(btnNewButton_3);
		
		JLabel lblNewLabel = new JLabel("");
		//lblNewLabel.setIcon(new ImageIcon("/gan.jpg"));
				
		ImageIcon icon=new ImageIcon(this.getClass().getResource("/gan.jpg"));
		lblNewLabel.setIcon(icon);		
		lblNewLabel.setBounds(0, 0, 758, 576);
		frame.getContentPane().add(lblNewLabel);
	}

}
