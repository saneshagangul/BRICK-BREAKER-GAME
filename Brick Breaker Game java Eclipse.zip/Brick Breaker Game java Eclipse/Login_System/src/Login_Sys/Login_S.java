 package Login_Sys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;

public class Login_S {

	private JFrame frame;
	private JTextField txtUserName;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	//public static void NewScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_S window = new Login_S();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_S() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame =   new JFrame();
		frame.setBounds(200, 200, 889, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUserName = new JLabel("userName");
		lblUserName.setOpaque(true);
		lblUserName.setForeground(Color.WHITE);
		lblUserName.setBackground(Color.BLACK);
		lblUserName.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblUserName.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserName.setBounds(44, 124, 155, 34);
		frame.getContentPane().add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setOpaque(true);
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setBackground(Color.BLACK);
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setBounds(44, 190, 155, 34);
		frame.getContentPane().add(lblPassword);
		
		txtUserName = new JTextField();
		txtUserName.setBounds(319, 126, 240, 40);
		frame.getContentPane().add(txtUserName);
		txtUserName.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(319, 184, 240, 40);
		frame.getContentPane().add(txtPassword);
		
		JButton btnlogin = new JButton("LOGIN");
		btnlogin.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnlogin.setBackground(Color.CYAN);
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String  password=txtPassword.getText();
				String  username=txtUserName.getText();
				
				
				
				if(password.contains("King") && username.contains("one") )
						{
					       txtPassword.setText(null);
					       txtUserName.setText(null);
					       
					       //Travelling info=new Travelling();
					       //Details detail1=new Details();
					       //Travelling.main(null);
 					       //  detail1.NewScreen();
					       //info.main(null);
					       
						}else
						{
						   	JOptionPane.showMessageDialog(null,"Invalid Login Details","Login Error",JOptionPane.ERROR_MESSAGE);
						}
				
			}
		});
		btnlogin.setBounds(20, 580, 119, 40);
		frame.getContentPane().add(btnlogin);
		
		JButton btnREST = new JButton("RESET");
		btnREST.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnREST.setBackground(Color.CYAN);
		btnREST.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtUserName.setText(null);
				txtPassword.setText(null); 
				
			}
		});
		btnREST.setBounds(339, 473, 155, 40);
		frame.getContentPane().add(btnREST);
		
		JButton btnEXIT = new JButton("EXIT");
		btnEXIT.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnEXIT.setBackground(Color.CYAN);
		btnEXIT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFrame frmLoginSystem = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frmLoginSystem,"Confirm if you want to exit","Login Systems",JOptionPane.YES_NO_OPTION
						)==JOptionPane.YES_NO_OPTION) {
					
					System.exit(0);
				}
				
				
			}
		});
		btnEXIT.setBounds(695, 580, 114, 40);
		frame.getContentPane().add(btnEXIT);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 222, 739, 2);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 59, 508, -3);
		frame.getContentPane().add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(10, 47, 729, 2);
		frame.getContentPane().add(separator_2);
		
		JLabel lblNewLabel = new JLabel("");
		ImageIcon icon=new ImageIcon(this.getClass().getResource("/edit11.jpg"));
		lblNewLabel.setIcon(icon);	
		lblNewLabel.setBounds(0, -43, 875, 767);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnlogin_1 = new JButton("LOGIN");
		btnlogin_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnlogin_1.setBackground(Color.CYAN);
		btnlogin_1.setBounds(286, 562, 119, 40);
		frame.getContentPane().add(btnlogin_1);
		
		JButton btnSignUp = new JButton("SIGN UP");
		btnSignUp.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnSignUp.setBackground(Color.CYAN);
		btnSignUp.setBounds(188, 580, 119, 40);
		frame.getContentPane().add(btnSignUp);
	}
}
