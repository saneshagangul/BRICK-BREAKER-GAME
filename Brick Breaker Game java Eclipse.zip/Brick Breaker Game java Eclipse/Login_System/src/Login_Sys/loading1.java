package Login_Sys;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;

public class loading1 {

	private JFrame frame;
	private static JProgressBar progressBar;
	private static JLabel lblNewLabel_1;
	private JProgressBar progressBar_1;
	private JProgressBar progressBar_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		int a;
		
		loading1 window = new loading1();
		window.frame.setVisible(true);
try {
for(a=0;a<=100;a++)
{
	loading1.progressBar.setValue(a);
	Thread.sleep(50);
	loading1.lblNewLabel_1.setText(Integer.toString(a)+" %" );
	if(a==100)
	{
		window.frame.dispose();
	}
}
		
}catch(InterruptedException e)
{
	e.printStackTrace(); 
}
	}

	/**
	 * Create the application.
	 */
	public loading1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100,763, 701);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		 progressBar = new JProgressBar();
		progressBar.setBackground(Color.CYAN);
		progressBar.setForeground(Color.BLUE);
		progressBar.setBounds(0, 625, 749, 39);
		frame.getContentPane().add(progressBar);
		
		JLabel lblNewLabel = new JLabel("");
		ImageIcon icon=new ImageIcon(this.getClass().getResource("/edit6.jpg"));
		lblNewLabel.setIcon(icon);
		lblNewLabel.setBounds(0, 0, 749, 587);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBackground(Color.YELLOW);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 34));
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setBounds(284, 585, 152, 39);
		frame.getContentPane().add(lblNewLabel_1);
		
		progressBar_1 = new JProgressBar();
		progressBar_1.setBackground(Color.YELLOW);
		progressBar_1.setBounds(0, 585, 284, 39);
		frame.getContentPane().add(progressBar_1);
		
		progressBar_2 = new JProgressBar();
		progressBar_2.setBackground(Color.YELLOW);
		progressBar_2.setBounds(435, 585, 314, 39);
		frame.getContentPane().add(progressBar_2);
	}

}
