package Login_Sys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Registration {

	private JFrame frame;
	private JTextField txtLname;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JTextField txtPassword;
	private JTextField txtUname;
	private JTextField txtCpassword;
	private JTextField txtFname;
	private JLabel lblNewLabel_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration window = new Registration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Registration() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 950,743);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setHorizontalTextPosition(SwingConstants.LEADING);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setBounds(33, 395, 163, 37);
		frame.getContentPane().add(lblNewLabel_1);
		
		txtLname = new JTextField();
		txtLname.setBounds(368, 234, 325, 46);
		frame.getContentPane().add(txtLname);
		txtLname.setColumns(10);
		
		lblNewLabel = new JLabel("First Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBounds(33, 165, 163, 37);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("Last Name");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setOpaque(true);
		lblNewLabel_2.setBounds(33, 243, 163, 37);
		frame.getContentPane().add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("User Name");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBackground(Color.BLACK);
		lblNewLabel_3.setOpaque(true);
		lblNewLabel_3.setBounds(33, 316, 163, 37);
		frame.getContentPane().add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Confirm Password");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBackground(Color.BLACK);
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setOpaque(true);
		lblNewLabel_4.setBounds(33, 472, 163, 37);
		frame.getContentPane().add(lblNewLabel_4);
		
		JButton btnSignUp = new JButton("SIGN UP");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			String Fname=txtFname.getText();
			String Lname=txtLname.getText();
			String Uname=txtUname.getText();
			String password=txtPassword.getText();
			String cpassword=txtCpassword.getText();
			
			
			String msg=""+Fname;
			msg+="\n";
			try {
			Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/cis_game","root","");
			
			String query="INSERT INTO account VALUES ('"+Fname+"','"+Lname+"','"+Uname+"','"+password+"','"+cpassword+"')";
			Statement sta=connection.createStatement();
			int x=sta.executeUpdate(query);
			if(x==0)
			{
				JOptionPane.showMessageDialog(btnSignUp, "This is already exit");
			}else {
				JOptionPane.showMessageDialog(btnSignUp,"welcome"+msg+"Your account is sucessfully created");
				
			}
			connection.close();
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			//JOptionPane.showMessageDialog(null,"Register Successfully",null,0,null);
						
			}
		});
		btnSignUp.setBackground(Color.CYAN); 
		btnSignUp.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnSignUp.setBounds(55, 603, 163, 57);
		frame.getContentPane().add(btnSignUp);
		
		JButton btnEXIT = new JButton("EXIT");
		btnEXIT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFrame frmLoginSystem = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frmLoginSystem,"Confirm if you want to exit","Registration System",JOptionPane.YES_NO_OPTION
						)==JOptionPane.YES_NO_OPTION) {
					
					System.exit(0);
				}				
			}
		});
		btnEXIT.setBackground(Color.CYAN);
		btnEXIT.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnEXIT.setBounds(691, 603, 163, 57);
		frame.getContentPane().add(btnEXIT);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtFname.setText(null);
				txtLname.setText(null);
				txtUname.setText(null);
				txtPassword.setText(null);
				txtCpassword.setText(null);
				
				
				
			}
		});
		btnReset.setBackground(Color.CYAN);
		btnReset.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnReset.setBounds(368, 603, 163, 57);
		frame.getContentPane().add(btnReset);
		
		txtPassword = new JPasswordField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(368, 391, 325, 46);
		frame.getContentPane().add(txtPassword);
		
		txtUname = new JTextField();
		txtUname.setColumns(10);
		txtUname.setBounds(368, 312, 325, 46);
		frame.getContentPane().add(txtUname);
		
		txtCpassword = new JPasswordField();
		txtCpassword.setColumns(10);
		txtCpassword.setBounds(368, 468, 325, 46);
		frame.getContentPane().add(txtCpassword);
		
		txtFname = new JTextField();
		txtFname.setColumns(10);
		txtFname.setBounds(368, 156, 325, 46);
		frame.getContentPane().add(txtFname);
		
		lblNewLabel_5 = new JLabel("");
		ImageIcon icon2=new ImageIcon(this.getClass().getResource("/edit12.jpg"));
		lblNewLabel_5.setIcon(icon2);	
		lblNewLabel_5.setBounds(0, 0,936,706);
		frame.getContentPane().add(lblNewLabel_5);
	}
}
